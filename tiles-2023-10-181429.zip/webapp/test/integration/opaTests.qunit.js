/* global QUnit */

sap.ui.require(["com/bhatia/tiles/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
